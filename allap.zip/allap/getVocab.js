var words = document.getElementsByClassName("word");
var notestring ="Notes:"
var lastel;
var lastrel;
var hilit=[]

var showNotes = function() {

	var gloss = this.getAttribute("data-lemma")
	var mod = this.getAttribute("data-mod")
	lemma=gloss+"_"+mod
	var fields=glossary[lemma]
    entry=fields[0]
    gloss1=fields[2]
    gloss2=fields[3]
    vocpos=fields[1]

	console.log(lemma, entry, gloss1, gloss2, vocpos)
	notestring = "<div class=\"vocabinfo\">"
	notestring += "<div class=\"parseinfo definition\"><span class=\"lemma\">"+entry+":</span> <span class=\"gloss1\">" + gloss1 + "</span></div>"
	if (gloss1 != gloss2 & gloss2 !=""){
		notestring += "<div class=\"parseinfo gloss2\">["+ gloss2 + "]</div>"
	}

	perseus=lemma.toLowerCase().replace("_","")
	lsurl="http://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.04.0059%3Aentry%3D"+perseus
	lslink="<a href='"+lsurl+"' target='_blank'>Lewis and Short Entry at Perseus</a>"
	console.log(lslink)
	notestring += "<div class=\"parseinfo\" id=\"lsurl\">"+lslink+"</div>"
	document.getElementById("notes1").innerHTML = notestring;
	lastel = this
};

document.addEventListener('DOMContentLoaded', function(){ 
	
	
	glossel=document.getElementById('glossary')
	glosstxt = glossel.innerText || glossel.textContent;
	glossary = JSON.parse(glosstxt)	
	for (var i = 0; i < words.length; i++) {
   		words[i].addEventListener('click', showNotes, false);
}}, false);
